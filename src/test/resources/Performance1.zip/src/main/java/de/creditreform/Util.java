package de.creditreform;

import java.sql.ResultSet;

public class Util {

    public static void createTableIfNotExist(){
        try {
            Config config = ConfigFactory.instance().getTestConfiguration();
            if (isTableExit())
                return;
            DbConnection conn = new DbConnection();
            boolean ins = conn.execute(config.getDb().getScript());
            if (ins){
                TestLogger.logWrite("Table Created");
                System.out.println("Table Created");
            } else {
                TestLogger.logWrite("Table Not Created");
                System.out.println("Table NOT Created");
            }
        }catch (Exception e){
            throw new RuntimeException(e);
        }

    }

    public static boolean isTableExit(){
        try {
            Config config = ConfigFactory.instance().getTestConfiguration();
            String schema = config.getDb().getSchema();
            String table = config.getDb().getTable();
            String sql = "SELECT count(*) " +
                    "FROM information_schema.TABLES " +
                    "WHERE (TABLE_SCHEMA = '" + schema + "') AND (TABLE_NAME = '" + table + "')";
            DbConnection conn = new DbConnection();
            ResultSet rs = conn.executeQuery(sql);
            int count = 0;
            while (rs.next()) {
                count = rs.getInt(1);
            }
            return count > 0;
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public static void sleep(int secs){
        try {
            Thread.sleep(secs * 1000L);
        }catch (Exception ignored){}
    }
}
