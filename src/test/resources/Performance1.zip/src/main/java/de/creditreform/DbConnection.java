package de.creditreform;


import java.sql.*;

public class DbConnection {
    private Connection conn;
    private Statement stmt;

    public DbConnection() {
        try {
            Config config = ConfigFactory.instance().getTestConfiguration();
            String url = config.getDb().getUrl();
            String username = config.getDb().getUsername();
            String password = config.getDb().getPassword();
            conn = DriverManager.getConnection(url, username, password);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        } catch (Exception e) {
            close();
            throw new RuntimeException(e);
        }
    }


    public boolean execute(String sql) {
        try {
            return stmt.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int executeUpdate(String sql) {
        try {
            return stmt.executeUpdate(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ResultSet executeQuery(String sql) {
        try {
            return stmt.executeQuery(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void close() {
        try {
            if (stmt != null) {
                stmt.close();
                stmt = null;
            }
            if (conn != null) {
                conn.close();
                conn = null;
            }
        } catch (Exception ignored) {
        }

    }

}
