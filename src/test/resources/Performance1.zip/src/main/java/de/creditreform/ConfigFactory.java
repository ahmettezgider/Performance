package de.creditreform;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;


public final class ConfigFactory {

    class LevelJsonSerializer extends JsonSerializer<Level> {

        @Override
        public void serialize(Level value, JsonGenerator gen, SerializerProvider serializers) throws IOException, IOException {
            gen.writeString(value.getName());
        }
    }

    class LevelJsonDeserializer extends JsonDeserializer<Level> {

        @Override
        public Level deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
            String name = p.getText();

            return Level.parse(name);
        }
    }


    private final static String CONFIG_FILE_NAME = "clients.yml";

    private static ConfigFactory instance;
    private Config clients;

    private ConfigFactory() throws IOException {
        File file = null;

        ArrayList<File> configFiles = new ArrayList<File>();
        {
            configFiles.add(new File(ConfigFactory.CONFIG_FILE_NAME));
        };


        for(int i = 0; i<configFiles.size() && file==null; i++) {
            if(configFiles.get(i).exists()) {
                if(configFiles.get(i).canRead()) {
                    file = configFiles.get(i);
                    //System.out.println("Using configuration file " + configFiles.get(i).getAbsolutePath());
                } else {
                    System.out.println("Configuration file not readable " + configFiles.get(i).getAbsolutePath() + " check next!");
                }
            } else {
                System.out.println("Configuration file not existing " + configFiles.get(i).getAbsolutePath() + " check next!");
            }
        }

        if (file != null) {
            SimpleModule levelModule = new SimpleModule("LevelModule");
            levelModule.addSerializer(Level.class, new LevelJsonSerializer());
            levelModule.addDeserializer(Level.class, new LevelJsonDeserializer());

            ObjectMapper om = new ObjectMapper(new YAMLFactory());
            om.registerModule(levelModule);
            clients = om.readValue(file, Config.class);
        } else {
            System.out.println("no configuration file found!");
            System.exit(1);
        }
    }

    public static ConfigFactory instance() throws IOException {
        instance = instance == null ? new ConfigFactory() : instance;
        return instance;
    }

    public Config getTestConfiguration() {
        return clients;
    }
}
