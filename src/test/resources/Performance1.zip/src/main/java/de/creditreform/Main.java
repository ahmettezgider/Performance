package de.creditreform;

import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.time.LocalTime;
import java.util.List;

public class Main {


    static String format = "%-15s%-2s%s\n";
    static LocalTime start;
    static LocalTime stop;
    static int interval;
    static Config config;

    public static void main(String[] args) throws Exception {
        System.out.println("App started");
        config = ConfigFactory.instance().getTestConfiguration();
        start = LocalTime.parse(config.getTests().getStart());
        stop = LocalTime.parse(config.getTests().getStop());
        interval = config.getTests().getInterval();
        System.out.println("Start time: " + start);
        System.out.println("Stop time: " + stop);
        System.out.println("Interval: " + interval + " seconds");
        Util.createTableIfNotExist();
        while (true){
            LocalTime now = LocalTime.now();
            if (now.isBefore(start) || now.isAfter(stop)) break;
            writeData();
            Util.sleep(interval);
        }
        System.out.println("App stopped");
        System.exit(0);
    }

    public static void writeData(){

        List<Config.Client> clients = config.getClients();
        for (Config.Client client : clients) {

            String name = client.getName();
            String url = client.getUrl();
            String ip = client.getIp();
            String server_status = isServerAlive(ip);
            int ikaros_status = urlResponseCode(url);
            String sql = "INSERT INTO " + config.getDb().getSchema() +
                    "(name, url, ip, server_status, ikaros_status) " +
                    "VALUES('" + name + "', '" + url + "', '" + ip + "', '" + server_status + "', " + ikaros_status + ");";
            DbConnection conn = new DbConnection();
            int num = conn.executeUpdate(sql);
            String data = "Name: " + name + ", " +
                    "Url: " + url + ", " +
                    "Ip: " + ip + ", " +
                    "Server_Status: " + server_status + ", " +
                    "Ikaros Status: " + ikaros_status;
            if (num > 0){
                TestLogger.logWrite("[Inserted] " + data);
                System.out.println("[Inserted] " + data);
            } else {
                TestLogger.logWrite("[Not Inserted] " + data);
                System.out.println("[Not Inserted] " + data);
            }
            conn.close();
        }

    }

    public static int urlResponseCode(String url) {
        try {
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("HEAD");
            con.setConnectTimeout(1000);
            return con.getResponseCode();
        } catch (Exception e) {
            return 0;
        }
    }

    public static String getResponseMessage(String url) {
        try {
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("HEAD");
            con.setConnectTimeout(1000);
            return con.getResponseMessage();
        } catch (Exception e) {
            return "Error";
        }
    }

    public static String isServerAlive(String ip) {

        InetAddress inet = null;
        try {
            inet = InetAddress.getByName(ip);
            if (inet.isReachable(5000)) {
                return "ALIVE";
            } else {
                return "DEAD";
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }

    public static void isAlive(String url) {
        try {
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("HEAD");
            con.setConnectTimeout(1000);
            if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                System.out.printf("%-18s%-2s%s\n", "Response Code", ":", con.getResponseCode());
                System.out.printf("%-18s%-2s%s\n", "Response Message", ":", con.getResponseMessage());
            } else if (con.getResponseCode() >= 500) {
                System.out.println("Server error");
            } else if (con.getResponseCode() >= 400) {
                System.out.println("Client error");
            }
        } catch (Exception e) {
            System.out.println("IO input is wrong: " + e);
        }
    }
}
