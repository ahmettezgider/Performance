package de.creditreform;

import java.sql.ResultSet;
import java.sql.SQLException;

import static de.creditreform.DbConnection.*;
public class DBMain {

    public static void main(String[] args) throws SQLException {

        String sql = "SELECT id, name, adress, ip FROM p";
        String sql1 = "SELECT count(*) " +
                "FROM information_schema.TABLES " +
                "WHERE (TABLE_SCHEMA = 'performance') AND (TABLE_NAME = 'performance')";
        DbConnection conn = new DbConnection();
        ResultSet rs = conn.executeQuery(sql1);
        int count = 0;
        while (rs.next()){
            count = rs.getInt(0);
        }
        conn.close();

    }
}
